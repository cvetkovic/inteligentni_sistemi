# Intelligent Systems

Dots and Boxes

Author: Lazar M. Cvetković

E-mail: l.cvetkovic.997@gmail.com

Date: December 2019
