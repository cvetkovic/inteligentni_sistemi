﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace etf.dotsandboxes.cl160127d.Game
{
    enum Player : int
    {
        BLUE = 0,
        RED = 1
    }
}
